// IPwry.cpp : �������̨Ӧ�ó������ڵ㡣
//

//#define write_sections
//#define debug_layer

#include "stdafx.h"
#include "windows.h"

//STL
#include <ctime>
#include <functional>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <string>
#include <deque>
#include <set>
#include <map>
#include <vector>
#include <list>
using namespace std;

//program_options
#include <boost/program_options/options_description.hpp>
#include <boost/program_options/variables_map.hpp>
#include <boost/program_options/parsers.hpp>
namespace po = boost::program_options;
const char boost_ver[] = "Boost (ver:1.32.0)";

//MD5, CRC32
#include "md5.h"

//lzma
#define INITGUID
#include "7zip/7zip/Compress/lzma/LZMAEncoder.h"
#include "7zip/7zip/Compress/LZMA_Alone/LzmaRam.h"
const char lzma_ver[] = "LZMA (ver:4.22)";

//���б���
struct program_env
{
	string input_file;   //�����ļ�
	string output_file;  //����ļ�

	bool do_ipwry;       //����ipwry
	bool do_gbwry;       //����gbwry
	bool do_text;        //����ipdata.txt
	bool use_lzma;       //ʹ��lzma
	bool ipsearcher;     //����dll

	string discard;      //�����ĵ�ַ

	bool count_time;     //��ʱ

	program_env()
	{
		do_ipwry = true;
		do_gbwry = false;
		do_text = false;
		use_lzma = false;
		ipsearcher = false;
		discard = "";
		count_time = true;
	}
};
program_env g_env;

const char format_ver = 2;
const char copyright[] = "cnss Copyright (c) 2004-2005.";
const string ver_str = "ipwry 0.2.2c";
const string mid_str = "(ty&&ml)";
const string null_s1 = "";
const string null_s2 = "";

//��ת������
const unsigned char jump_l_l = 0;
const unsigned char jump_j_l = 1;
const unsigned char jump_l_j = 2;
const unsigned char jump_j_j = 3;
const unsigned char jump_aj  = 4;

const unsigned char jump_l_n = 5;
const unsigned char jump_j_n = 6;
const unsigned char jump_n_l = 7;
const unsigned char jump_n_j = 8;
const unsigned char jump_uk  = 9;

const unsigned char jump_f_l = 10;
const unsigned char jump_f_j = 11;
const unsigned char jump_f_n = 12;
const unsigned char jump_l_f = 13;
const unsigned char jump_j_f = 14;
const unsigned char jump_n_f = 15;

const unsigned int NOT_USE = 0xFFFFFFFF;

//qqwry.dat
unsigned int len = 0;   //����
char *ptr = NULL; //����ָ��
unsigned int old_count = 0;  //���ж�������ЧIP

struct ip_piece
{
	unsigned int id;
	unsigned int begin, end;
	unsigned int s, s1, s2;
	bool is_null;
};

struct count_id_last
{
	unsigned int a;  //���ִ���
	unsigned int id; //ΨһID
	unsigned int last_id; //�����ֵ�IPƬ��ID
	bool operator<(const count_id_last &s) const
	{
		return a < s.a;
	}
	bool operator>(const count_id_last &s) const
	{
		return a > s.a;
	}
	count_id_last(const unsigned int _a, const unsigned int _id, const unsigned int _last_id = 0)
	{
		a = _a;
		id = _id;
		last_id = _last_id;
	}
	count_id_last()
	{
	}
};

struct same_all_struct //ȫ��ַ�ṹ
{
	string s1, s2;
	//unsigned int count;
	unsigned int offset;
	bool use_father;
	same_all_struct(const string &_s1, const string &_s2)
	{
		s1 = _s1;
		s2 = _s2;
		//count = 1;
		offset = NOT_USE;
		use_father = false;
	}
	same_all_struct()
	{
		//count = 1;
		offset = NOT_USE;
		use_father = false;
	}
};
struct same_sub_struct //���ַ�ṹ
{
	string str;
	unsigned int offset;
	same_sub_struct(const string &_str)
	{
		str = _str;
		offset = NOT_USE;
	}
	same_sub_struct()
	{
		offset = NOT_USE;
	}
};

struct string_cmpr //�Ƚ����ַ���
{
	string str;
	unsigned int crc;

	string_cmpr(const string &s)
	{
		str = s;
		crc = _CRC32( s );
	}
	string_cmpr()
	{
	}

	bool operator==(const string_cmpr &s) const
	{
		if(crc != s.crc)
			return false;
		if(str != s.str)
			return false;
		return true;
	}
	bool operator<(const string_cmpr &s) const
	{
		if(crc != s.crc)
			return crc < s.crc;
		return str < s.str;
	}
};

struct scan_piece  //��������ɨ��Ľ��
{
	unsigned int max_id; //����Ψһ��id
	unsigned int count;  //�ж��ٸ�
	unsigned int begin, end; //ip_deque��id, ����IP
};

struct count_posion  //��������ɨ��ʱ�Ŀ�������
{
	unsigned int count;  //����
	list<count_id_last>::iterator position;  //λ��

	count_posion(const unsigned int _count, const list<count_id_last>::iterator _position)
	{
		count = _count;
		position = _position;
	}
	count_posion()
	{
	}
};

#pragma pack(push,1)
struct data_header  //IPƬ����ͷ 1b
{
	unsigned char jump:   4;  //��ת��ʽ
	unsigned char has_child: 1;  //�Ƿ��к���
	unsigned char differ: 3;  //�������
};
struct date_time  //����ʱ�� 4b
{
	unsigned int year:  7; //128
	unsigned int month: 4; //16
	unsigned int day:   5; //32

	unsigned int hour:  5;
	unsigned int min:   6;
	unsigned int sec:   5;
};
struct file_header  //�ļ�ͷ
{
	//������  13
	unsigned int  crc;
	unsigned char ver;
	date_time     date;
	unsigned int  total;
	//������  5
	unsigned char data_len;  //������ռ�����ֽ�
	unsigned int  data_ptr;  //��������ʼ
	//�ֵ�   10
	unsigned char dic_len;   //����ռ���ֽ�
	unsigned int  dic_count; //�ֵ���Ŀ
	unsigned char dic_chr;   //ת���ֽ�
	unsigned int  dic_ptr;   //�ֵ�����ʼ
	//ѹ��  13
	char compress_type;  //ѹ���㷨
	unsigned int compress_begin; //ѹ����ʼ
	unsigned int compress_len;   //ѹ�����ݵĳ���
	unsigned int compress_org;   //ԭʼ����
	//������  16
	unsigned int layer1_ptr;
	unsigned int layer1_num;
	unsigned int layer2_ptr;
	unsigned int layer2_num;
};
#pragma pack(pop)

deque<ip_piece> ip_deque; //��¼ÿƬIP���ݵ���Ϣ
map<string_cmpr, unsigned int> all_str;  //�ظ��Ĺ���,Ψһ��id
map<string_cmpr, unsigned int> sub_str;  //�ظ����Ӵ�,Ψһ��id

deque<same_all_struct> all_map;  //ȫΨһ��id, ��Ϣ
deque<same_sub_struct> sub_map;  //��Ψһ��id, ��Ϣ

unsigned int all_str_len = 0; //�����ַ����ĳ���

//����N���ֽ�
inline void strcpyn(char *d, const char *s, int len)
{
	while(*s && len > 1)
	{
		*d++ = *s++;
		--len;
	}
	*d = NULL;
}

//����->�ַ���
const unsigned int MAX_BUFFER = 32;
inline char* d2str(unsigned int intValue, char* const charValue) 
{
	unsigned int i;
	unsigned int colnum = 0;

	do
	{
		i = intValue % 10;
		intValue = intValue / 10;

		*(charValue + MAX_BUFFER - colnum - 1) = i + '0';
		++colnum;
	}
	while(intValue > 0 && colnum < MAX_BUFFER);

	*(charValue + MAX_BUFFER) = NULL;
	return charValue + MAX_BUFFER - colnum;
}

//IP->�ַ���
inline string ip2str(const unsigned int ip)
{
	char buffer[MAX_BUFFER + 1];
	string temp;

	unsigned char n;
	for(unsigned int i = 0; i < 3; ++i)
	{
		n = *((unsigned char*)&ip + 3 - i);
		temp.append( d2str(n, buffer) );

		temp.append(".");
	}
	n = *(unsigned char*)&ip;
	temp.append( d2str(n, buffer) );

	return temp;
}

//dump IP
void write_ip()
{
	ip_piece temp;

	ofstream output_file( g_env.output_file.c_str() );

	if(!output_file)
		return;

	output_file << (unsigned int)ip_deque.size() << endl;
	for(unsigned int i = 0; i < ip_deque.size(); ++i)
	{
		temp = ip_deque[i];

		if( !temp.is_null )
		{
			output_file << ip2str(temp.begin) << "	" << ip2str(temp.end) << "	" 
				<< sub_map[temp.s1].str << "	" << sub_map[temp.s2].str << endl;
		}
	}

	output_file.close();
}

//װ��QQWRY
bool load_qqwry()
{
	fstream f;

	f.open(g_env.input_file.c_str(), ios::in | ios::binary);
	if(!f)
	{
		cout << "�޷���" << g_env.input_file << endl;
		return false;
	}

	//�õ���С,�����ڴ�
	f.seekg(0, ios::end);
	len = f.tellg();

	ptr = new char[len+1];

	//��ȡ
	f.seekg(0, ios::beg);
	f.read(ptr, len);

	f.close();

	return true;
}

//ȥ�ո�
inline void trim(string &s)
{
	// ȥ�ո�
	const char c = ' ';
	s.erase(0, s.find_first_not_of(c));
	string::reverse_iterator i = find_if(s.rbegin(), s.rend(), bind2nd(not_equal_to<char>(), c));
	s.erase(i.base(), s.end());
}

//����ȫ��ַ
inline unsigned int add_all_str(const string &s1, const string &s2)
{
	string_cmpr sc = string_cmpr(s1 + mid_str + s2);

	if( all_str.find(sc) != all_str.end() ) //����
	{
		//++all_map[all_str[sc]].count;  //ȫַ����+1
		return all_str[sc];
	}
	else //����
	{
		all_map.push_back( same_all_struct(s1, s2) );
		all_str.insert( make_pair(sc, static_cast<unsigned int>(all_str.size()) ) );
		return static_cast<unsigned int>(all_str.size()) - 1;
	}
}

//����һ���ӵ�ַ
inline unsigned int add_sub_str(const string &str)
{
	string_cmpr sc = string_cmpr(str);

	if( sub_str.find(sc) != sub_str.end() ) //����
		return sub_str[sc];
	else //����
	{
		all_str_len += static_cast<unsigned int>(str.size()) + 1;

		sub_map.push_back( same_sub_struct(str)	);
		sub_str.insert( make_pair(sc, static_cast<unsigned int>(sub_str.size()) ) );
		return static_cast<unsigned int>(sub_str.size()) - 1;
	}
}

//3�ֽ�����
inline unsigned int get_3b(const char *mem)
{
	return 0x00FFFFFF & *(unsigned int*)mem;
}

//��qqwry��ȡ
bool read()
{
	char *p = (ptr + *(unsigned int*)ptr);  //ptr of index area

	unsigned int total;
	//calc total-1
	total = (*((unsigned int*)ptr+1) - *(unsigned int*)ptr);

	//����Ƿ�����
	if( len < 10
		|| *((unsigned int*)ptr+1) <= *(unsigned int*)ptr 
		|| total % 7 != 0 
		|| *((unsigned int*)ptr+1) > len - 6)
	{
		free(ptr);
		cout << g_env.input_file << "�ļ�����" << endl;
		return false;
	}
	total /= 7;

	ip_piece temp;
	char *country, *local;
	char *now_p;

	unsigned int id_sub = 0; //��ͬ�ھ�ʱ����id
	unsigned int id_add = 0; //�ն�ʱ����id
	unsigned int now_end = 0; //IP��ֹ��

	for(unsigned int i = 0; i <= total; ++i)
	{		
		//begin
		temp.begin = *(unsigned int*)(p + 7 * i);

		//end
		now_p = ptr + get_3b(p + 7 * i + 4);
		temp.end = *(unsigned int*)now_p;
		now_p += 4;

		if( 0x02 < *now_p && *now_p < 0x0A )
		{
			cout << g_env.input_file << "������һ��qqwry.dat���ָ�ʽ,����������֧��." << endl;
			return false;
		}

		if( 0x01 == *now_p )
			now_p = ptr + get_3b(now_p + 1);
		//country
		if( 0x02 == *now_p ) //jump
		{
			country = ptr + get_3b(now_p + 1);
			now_p += 4;
		}
		else
		{
			country = now_p;
			for(; *now_p; ++now_p)
				;
			++now_p;
		}
		//local
		if( 0x02 == *now_p ) //jump
			local = ptr + get_3b(now_p + 1);
		else
			local = now_p;

		//s, s1, s2 ��ȥ�ո�
		string temp_s1 = string(country);
		string temp_s2 = string(local);
		trim(temp_s1);
		trim(temp_s2);

		//����
		if( !g_env.discard.empty() )
		{
			if( temp_s1 == g_env.discard )
				temp_s1 = "";
			if( temp_s2 == g_env.discard )
				temp_s2 = "";
		}

		temp.s1 = add_sub_str(temp_s1);
		temp.s2 = add_sub_str(temp_s2);
		temp.s  = add_all_str(temp_s1, temp_s2);

		//id
		temp.id = i - id_sub + id_add;

		//�Ƿ��
		if( temp_s1.empty() && temp_s2.empty() )
			temp.is_null = true;
		else
			temp.is_null = false;

		//ȷ��û���߼�����
		if( !ip_deque.empty() && 
			(ip_deque.back().end >= temp.begin || temp.begin > temp.end)
			)
		{
			cout << "QQwry.dat���߼�����,��ȷ���������ĳ���û������." << endl;
			return false;
		}

		//�пն�
		if( temp.begin > now_end + 1 && 0xFFFFFFFF != now_end ) 
		{
			//�ն�
			ip_piece temp1;
			temp1.begin = now_end + 1;
			temp1.end   = temp.begin - 1;
			temp1.id    = temp.id;
			temp1.is_null = true;
			temp1.s1    = add_sub_str(null_s1);
			temp1.s2    = add_sub_str(null_s2);
			temp1.s     = add_all_str(null_s1, null_s2);

			ip_deque.push_back(temp1);

			++id_add;
			++temp.id;
		}
		now_end = temp.end;

		if( !ip_deque.empty() 
			&& ip_deque.back().s == temp.s
			&& ip_deque.back().end == temp.begin - 1 )  //����һ���ϲ�
		{
			ip_deque.back().end = temp.end;
			++id_sub;
		}
		else  //����
		{
			ip_deque.push_back(temp);
		}
	}

	cout << "����" << i - id_sub << "����Ч����" << endl;
	old_count = i - id_sub;

	//�ͷ�QQwry�ڴ�
	delete []ptr;

	//cout << "ȥ������:" << id_sub << endl;
	
	//дip_deque���ļ�
	if(g_env.do_text)
		write_ip();

	return true;
}

//һƬIP�Ƿ�Ϊ��
inline bool not_null(ip_piece& v)
{
	return !v.is_null;
}

//����gbwry
inline void make_gbwry()
{
	cout << "    [��л:������ʹ�õ�gbwry.dat��ʽ����������ṩ.]" << endl;

	if( sub_str.size() > 0xFFFF )
	{
		cout << "����:IP�����Ѿ�����gbwry.dat��ʽ�������ɵ��������,����ת��." << endl;
		g_env.count_time = false;
		return;
	}

	unsigned int ip_count;

	//�ж������ǿ�IP
	ip_count = (unsigned int)count_if(ip_deque.begin(), ip_deque.end(), not_null);

	unsigned int all_len = 26 + 12*ip_count + 4*sub_map.size() + all_str_len;
	char *all = new char[all_len];

	//������
	char* now_p = all + 26;

	deque<ip_piece>::iterator deque_i;
	for(deque_i = ip_deque.begin(); deque_i != ip_deque.end(); ++deque_i)
	{
		if( !deque_i->is_null )
		{
			//begin
			*(unsigned int*)now_p = deque_i->begin;
			now_p += 4;
			//end
			*(unsigned int*)now_p = deque_i->end;
			now_p += 4;
			//country
			*(unsigned short*)now_p = deque_i->s1;
			now_p += 2;
			//local
			*(unsigned short*)now_p = deque_i->s2;
			now_p += 2;
		}
	}
	//�ַ��������� & �ַ���
	unsigned int now_len = 0;
	char *pi = all + 26 + 12*ip_count;
	unsigned int ps = 26 + 12*ip_count + 4*sub_map.size();

	deque<same_sub_struct>::iterator submap_i;
	for(submap_i = sub_map.begin(); submap_i < sub_map.end(); ++submap_i)
	{
		//index
		*(unsigned int*)pi = now_len;
		pi += 4;
		//string
		strcpy(all + ps + now_len, submap_i->str.c_str());
		now_len += (unsigned int)submap_i->str.length() + 1;
	}

	//ͷ��Ϣ
	*(unsigned int*)(all + 16) = 0x1;
	*(unsigned int*)(all + 20) = ip_count;
	*(unsigned short*)(all + 24) = (unsigned short)sub_map.size();
	MD5::_MD5_16b(all + 16, all_len - 16, (unsigned char*)all);

	//д��
	fstream f;
	f.open(g_env.output_file.c_str(), ios::out | ios::binary);
	if(!f)
	{
		cout << "�޷�����" << g_env.output_file << endl;
		return;
	}

	f.seekg(0, ios::beg);
	f.write(all, all_len);
	f.close();

	delete []all;

	if( all_len > 10000000 )
		cout << "����: gbwry��С������10M, ĳЩ������ܲ�����װ����." << endl;

	cout << "qqwry: " << len << "�ֽ�  " << "gbwry: " << all_len << "�ֽ�  " 
		<< "ѹ����: " << (float)all_len / (float)len * 100 << "%" << endl;
}

//�û�������ɨ��
void scan(unsigned int wnd_size, unsigned int filter, deque<scan_piece> &scan_deque, deque<ip_piece> &tdeque = ip_deque)
{
	//ɨ����
	list<count_id_last> now_list;          //����, ��ǰ��������    ���ִ���/Ψһid
	map<unsigned int, count_posion> id_info_map; //map,  Ψһid-(count,λ��) �����ּ���

	unsigned int i, str_id;
	list<count_id_last>::iterator list_i, list_i_temp;
	map<unsigned int, count_posion>::iterator map_i;

	now_list.push_front( count_id_last(0, 0, 0) );
	list<count_id_last>::iterator list_0 = now_list.begin();
	unsigned int t1, t2, t3;

	for(i = 0; i <= tdeque.size() - wnd_size; ++i)
	{
		//��ʼ�Ƴ�===========================
		if(i >= wnd_size)
		{
			str_id = tdeque[i - wnd_size].s;

			if(1 >= id_info_map[str_id].count) //�����һ��
			{
				//��listɾ
				now_list.erase( id_info_map[str_id].position );

				map_i = id_info_map.find( str_id );
				id_info_map.erase( map_i );
			}
			else //�����е�,����
			{
				list_i_temp = list_i = id_info_map[str_id].position;

				//�ҵ���λ��
				while(1)
				{
					++list_i;
					if(list_i_temp->a > list_i->a)
						break;
				}
				--list_i_temp->a;

				t1 = list_i_temp->a;
				t2 = list_i_temp->id;
				t3 = list_i_temp->last_id;

				now_list.erase(list_i_temp);
				list_i = now_list.insert( list_i, count_id_last(t1, t2, t3) );

				id_info_map[str_id].position = list_i;
				--id_info_map[str_id].count;
			}
		}

		//���뵱ǰi==========================
		str_id = tdeque[i].s;

		if( id_info_map.find(str_id) == id_info_map.end() ) //���µ�Ψһ��id
		{
			//����list
			list_i = now_list.insert(list_0, count_id_last(1, str_id, i) );

			//����id_count_map
			id_info_map.insert( make_pair( str_id, count_posion(1, list_i) ) );
		}
		else //�����е�,ǰ��
		{
			//��list�е�λ��
			list_i_temp = list_i = id_info_map[str_id].position;

			//�ҵ���λ��
			while(1)
			{
				if(list_i->a > list_i_temp->a)
				{
					++list_i;
					break;
				}
				if(list_i == now_list.begin())
					break;
				--list_i;
			}
			++list_i_temp->a;

			//��Ҫ�ƶ�
			if(list_i != list_i_temp)
			{
				t1 = list_i_temp->a;
				t2 = list_i_temp->id;

				now_list.erase(list_i_temp);
				list_i = now_list.insert( list_i, count_id_last(t1, t2, i) );
				id_info_map[str_id].position = list_i;
			}
			++id_info_map[str_id].count;
			list_i->last_id = i;
		}

		//��¼==============================
		if(now_list.front().a >= filter && i >= wnd_size - 1)
		{
			unsigned int temp_i = i + 1 - wnd_size;

			if( !scan_deque.empty() )
			{
				if(scan_deque.back().max_id == now_list.front().id) //�ϲ�
					scan_deque.back().end = now_list.front().last_id;

				if( scan_deque.back().end >= temp_i ) //����
					temp_i = scan_deque.back().end + 1;

				if( scan_deque.back().end < temp_i - 1)  //����϶
					scan_deque.back().end = temp_i - 1;
			}

			if( temp_i <= now_list.front().last_id)
			{
				scan_piece temp;
				temp.begin = temp_i;
				temp.end   = now_list.front().last_id;
				temp.max_id = now_list.front().id;
				temp.count = now_list.front().a;

				scan_deque.push_back(temp);
			}
		}
	}
	//cout << "��Χ:" << wnd_size << " ����:" << filter 
	//	<< " �ܼ�:" << (unsigned int)scan_deque.size() << endl;

#if defined write_sections
	//����
	ofstream output_file("sections.txt");
	if(!output_file)
		return;

	output_file << (unsigned int)scan_deque.size() << endl;
	for(i = 0; i < scan_deque.size(); ++i)
	{
		output_file << scan_deque[i].begin << " "
			<< scan_deque[i].end << " "
			<< all_map[scan_deque[i].max_id].s1 << " "
			<< all_map[scan_deque[i].max_id].s2 << " " 
			<< scan_deque[i].count << endl;
	}
	output_file.close();
#endif
}

struct ip_node //IPƬ
{
	unsigned int begin, end; //��ʼ,����IP
	unsigned int s, s1, s2;   //�ܵ�,����,����

	unsigned int offset;   //�����������ƫ��

	vector<char> data;      //����
	unsigned int  data_len; //���ݳ���
};
struct temp_ip_node //��ʱIPƬ
{
	unsigned char differ;     //��ֱ���ռ���ֽ�
	int a_off, c_off, l_off; //������е�ƫ����
};
ip_node null_ip_node;

//�õ��������
inline unsigned int differ(const ip_node &node)
{
	unsigned int t = node.end - node.begin;

	if(0 == t)
		return 0;
	if(t <= 0xFF)
		return 1;
	if(t <= 0xFFFF)
		return 2;
	if(t <= 0xFFFFFF)
		return 3;
	return 4;
}

//���ɵ�ַ����
inline void make_jump(ip_node &node_ok, temp_ip_node &node, data_header *header)
{
	char *start = &(node_ok.data[0]) + 1 + node.differ;
	switch(header->jump)
	{
	case jump_l_l: //ԭ, ԭ
		strcpy(start, sub_map[node_ok.s1].str.c_str());
		strcpy(start+sub_map[node_ok.s1].str.length()+1, sub_map[node_ok.s2].str.c_str());
		break;
	case jump_j_l: //��, ԭ
		*(unsigned int*)start = node.c_off;
		strcpy(start + 3, sub_map[node_ok.s2].str.c_str());
		break;
	case jump_l_j: //ԭ, ��
		strcpy(start, sub_map[node_ok.s1].str.c_str());
		*(unsigned int*)(start+sub_map[node_ok.s1].str.length()+1) = node.l_off;
		break;
	case jump_j_j: //��, ��
		*(unsigned int*)start = node.c_off;
		*(unsigned int*)(start+3) = node.l_off;
		break;
	case jump_aj: // ȫ��
		*(unsigned int*)start = node.a_off;
		break;

	case jump_l_n: //ԭ, ��
		strcpy(start, sub_map[node_ok.s1].str.c_str());
		break;
	case jump_j_n: //��, ��
		*(unsigned int*)start = node.c_off;
		break;
	case jump_n_l: //��, ԭ
		strcpy(start, sub_map[node_ok.s2].str.c_str());
		break;
	case jump_n_j: //��, ��
		*(unsigned int*)start = node.l_off;
		break;
	case jump_uk: //δ֪
		break;

	case jump_f_l: //��, ԭ
		strcpy(start, sub_map[node_ok.s2].str.c_str());
		break;
	case jump_f_j: //��, ��
		*(unsigned int*)start = node.l_off;
		break;	
	case jump_f_n: //��, ��
		break;
	case jump_l_f: //ԭ, ��
		strcpy(start, sub_map[node_ok.s1].str.c_str());
		break;
	case jump_j_f: //��, ��
		*(unsigned int*)start = node.c_off;
		break;	
	case jump_n_f: //��, ��
		break;

	default:
		cout << "��ת���ִ���." << endl;
		break;
	}
}

//��������
void make_final(deque<ip_node> &level1, 
				deque<ip_node> &level2, 
				const unsigned int now_offset)
{
	unsigned int now; //�ܳ���

	//ͷ==============================================
	file_header f_header;

	f_header.data_len = 3;

	//����====================
	time_t tim = time(0);
	struct tm* lt = localtime( &tim );

	f_header.date.year  = 1900 + lt->tm_year - 2000;
	f_header.date.month = lt->tm_mon + 1;
	f_header.date.day   = lt->tm_mday;

	f_header.date.hour  = lt->tm_hour;
	f_header.date.min   = lt->tm_min;
	f_header.date.sec   = lt->tm_sec / 2;

	//�ֵ�===================
	//f_header.dic_chr
	f_header.dic_count = 0;
	//f_header.dic_len

	//����===================
	f_header.total = old_count;
	f_header.ver = format_ver;

	now = sizeof(file_header);  //һ��8,����16

	//�������ڴ�
	f_header.data_ptr = now;
	char *data = new char[now_offset];
	unsigned int data_count = 0;

	//�������ڴ�
	char *index = new char[(level1.size() + level2.size()) * 7 + 1];
	unsigned int index_count = 0;

	deque<ip_node>::iterator level_i;

	//layer1����===================
	f_header.layer1_ptr = now + now_offset;
	f_header.layer1_num = (unsigned int)level1.size()-1;

	for(level_i = level1.begin(); level_i != level1.end(); ++level_i)
	{
		//������
		memcpy(data + data_count, &(level_i->data[0]), level_i->data_len);

		data_count += level_i->data_len;
		level_i->data.clear();

		//������
		*(unsigned int*)(index + index_count) = level_i->begin;
		index_count += 4;
		*(unsigned int*)(index + index_count) = level_i->offset;
		index_count += 3;
	}

	//layer2����==================
	f_header.layer2_ptr = now + now_offset + index_count;
	f_header.layer2_num = (unsigned int)level2.size()-1;

	for(level_i = level2.begin(); level_i != level2.end(); ++level_i)
	{
		//������
		memcpy(data + data_count, &(level_i->data[0]), level_i->data_len);

		data_count += level_i->data_len;
		level_i->data.clear();

		//������
		*(unsigned int*)(index + index_count) = level_i->begin;
		index_count += 4;
		*(unsigned int*)(index + index_count) = level_i->offset;
		index_count += 3;
	}
	now += data_count;
	now += index_count;

	//��ʼ�������===========================
	char *all = new char[now + 1];

	//ͷ
	memcpy(all, (char*)&f_header, sizeof(file_header));

	//����
	memcpy(all + sizeof(file_header), data, data_count);
	delete []data;

	//����
	memcpy(all + sizeof(file_header) + data_count, index, index_count);
	delete []index;

	//lzmaѹ��
	((file_header*)all)->compress_type = 0;
	if(g_env.use_lzma)
	{
		//Ҫѹ���ĳ���
		unsigned int old_len = now - sizeof(file_header);
		unsigned int compress_len;
		//��ʼ��ַ
		char *source = all + sizeof(file_header);
		//�����ڴ�
		char *new_data = new char[old_len];

		//ѹ��
		cout << "����LZMAѹ��,���Ե�..." << endl;
		int c_result = LzmaRamEncode((Byte*)source, old_len, 
			(Byte*)new_data, old_len, 
			&compress_len, 
			old_len, SZ_FILTER_AUTO);

		//ѹ���ɹ�
		if(0 == c_result)
		{
			if(compress_len < old_len) //��ѹ��ǰС��
			{
				//����
				memcpy(all + sizeof(file_header), new_data+1, compress_len);
				delete []new_data;

				//ͷ
				((file_header*)all)->compress_type = 1;
				((file_header*)all)->compress_begin = sizeof(file_header);
				((file_header*)all)->compress_len = compress_len;
				((file_header*)all)->compress_org = old_len;

				unsigned int old_now = now;
				//�ļ�����
				now -= old_len - compress_len;

				cout << "ѹ���ɹ�, ѹ��ǰ:" << old_now << " ѹ����:" << now << endl;
			}
			else  //��ѹ��ǰ����
				delete []new_data;
		}
		else
		{
			delete []new_data;
			cout << "�޷�ѹ������.�������:" << c_result << endl;
		}
	}

	//����CRC32
	*(unsigned int*)all = _CRC32(all + 4, now - 4);

	//���ļ�
	fstream f;
	f.open(g_env.output_file.c_str(), ios::out | ios::binary);
	if(!f)
	{
		cout << "�޷���" << g_env.output_file << endl;
		return;
	}

	//д���ļ�
	f.seekg(0, ios::beg);
	f.write(all, now);
	f.close();

	delete []all;

	cout << "qqwry: " << len << "�ֽ�  " << "ipwry: " << now << "�ֽ�  " 
		<< "ѹ����: " << (float)now / (float)len * 100 << "%" << endl;
}

//class count_jump
//{
//	unsigned int number[16];
//	unsigned int all;
//public:
//	count_jump()
//	{
//		all = 0;
//		for(int i = 0; i < 16; ++i)
//			number[i] = 0;
//	}
//	void count(unsigned char jump)
//	{
//		++all;
//		++number[jump];
//	}
//	void print(void)
//	{
//		for(int i = 0; i < 16; ++i)
//			cout << i << " " << number[i] << " " << (float)number[i]*100/all << endl;
//	}
//};
//count_jump ddddd;

//��������
inline void make_data_piece(ip_node &node_ok, temp_ip_node &node, 
							 const bool has_childe, bool use_father, ip_node &father)
{
	unsigned char jump_type;  //��ת����
	//ȷ������ �� ��ת����
	if(add_all_str(null_s1, null_s2) == node_ok.s) //δ֪����
	{
		jump_type = jump_uk;
		node.a_off = -3;
	}
	else if(NOT_USE != all_map[node_ok.s].offset && !all_map[node_ok.s].use_father) //(ȫ������ �� ��ʹ�ø���)->ȫ��
	{
		jump_type = jump_aj;
		node.a_off = all_map[node_ok.s].offset;
		node_ok.data_len += 3;
	}
	else
	{
		all_map[node_ok.s].offset = node_ok.offset; //����ȫ��
		all_map[node_ok.s].use_father = use_father;

		if(use_father) //�ø�
		{
			if(node_ok.s1 == father.s1) //��ͬ��
			{
				if( !sub_map[node_ok.s2].str.empty() )  //����
				{				
					if(NOT_USE == sub_map[node_ok.s2].offset) //�µ�
					{
						jump_type = jump_f_l;
						sub_map[node_ok.s2].offset = node_ok.offset + node_ok.data_len;
						node_ok.data_len += (unsigned int)sub_map[node_ok.s2].str.length() + 1;
					}
					else //����
					{
						jump_type = jump_f_j;
						node.l_off = sub_map[node_ok.s2].offset;
						node_ok.data_len += 3;
					}
				}
				else  //����
				{
					jump_type = jump_f_n;
				}
			}
			else if(node_ok.s2 == father.s2) //��ͬ��
			{
				if( !sub_map[node_ok.s1].str.empty() )  //�й�
				{
					if(NOT_USE == sub_map[node_ok.s1].offset) //�µ�
					{
						jump_type = jump_l_f;
						sub_map[node_ok.s1].offset = node_ok.offset + node_ok.data_len;
						node_ok.data_len += (unsigned int)sub_map[node_ok.s1].str.length() + 1;
					}
					else //����
					{
						jump_type = jump_j_f;
						node.c_off = sub_map[node_ok.s1].offset;
						node_ok.data_len += 3;
					}
				}
				else  //�޹�
				{
					jump_type = jump_n_f;
				}
			}
		}
		else //���ø�
		{
			//��=====
			if( !sub_map[node_ok.s1].str.empty() )  //�й�
			{
				if(NOT_USE == sub_map[node_ok.s1].offset) //�µ�
				{
					sub_map[node_ok.s1].offset = node_ok.offset + node_ok.data_len;
					node_ok.data_len += (unsigned int)sub_map[node_ok.s1].str.length() + 1;
				}
				else //����
				{
					node.c_off = sub_map[node_ok.s1].offset;
					node_ok.data_len += 3;
				}
			}
			else  //�޹�
				node.c_off = -2;

			//��=====
			if( !sub_map[node_ok.s2].str.empty() )  //����
			{				
				if(NOT_USE == sub_map[node_ok.s2].offset) //�µ�
				{
					sub_map[node_ok.s2].offset = node_ok.offset + node_ok.data_len;
					node_ok.data_len += (unsigned int)sub_map[node_ok.s2].str.length() + 1;
				}
				else //����
				{
					node.l_off = sub_map[node_ok.s2].offset;
					node_ok.data_len += 3;
				}
			}  //����
			else
				node.l_off = -2;

			//��ת����
			if(-1 == node.c_off && -1 == node.l_off) //ԭ, ԭ
				jump_type = jump_l_l;
			else if(node.c_off >= 0 && -1 == node.l_off)  //��, ԭ
				jump_type = jump_j_l;
			else if(-1 == node.c_off && node.l_off >= 0)  //ԭ, ��
				jump_type = jump_l_j;
			else if(node.c_off >= 0 && node.l_off >= 0)   //��, ��
				jump_type = jump_j_j;

			else if(-1 == node.c_off && -2 == node.l_off) //ԭ, ��
				jump_type = jump_l_n;
			else if(node.c_off >= 0 && -2 == node.l_off)  //��, ��
				jump_type = jump_j_n;
			else if(-2 == node.c_off && -1 == node.l_off) //��, ԭ
				jump_type = jump_n_l;
			else if(-2 == node.c_off && node.l_off >= 0)  //��, ��
				jump_type = jump_n_j;
		}
	}
	//ddddd.count(jump_type);

	//��������
	node_ok.data.resize(node_ok.data_len + 3);

	data_header *header = (data_header*)&(node_ok.data[0]);
	header->differ    = node.differ;
	header->has_child = has_childe;
	header->jump      = jump_type;

	*(unsigned int*)&(node_ok.data[1]) = node_ok.end - node_ok.begin; //IP��
	make_jump(node_ok, node, header); //�ڲ�
}

//���ɨ��
void make_layer()
{
#if defined debug_layer
	ofstream debug("debug_layer.txt");

	if(!debug)
	{
		cout << "�޷���debug_layer.txt" << endl;
		return;
	}
#endif
	deque<scan_piece> ttt;
	scan(9, 2, ttt);

	//��һ��
	deque<ip_node> end_ip_deque1;

	//������
	unsigned int now_offset = 0;  //��ǰ������ָ��

	temp_ip_node node;
	ip_node node_ok;

	for(deque<scan_piece>::iterator l1i = ttt.begin(); l1i != ttt.end(); ++l1i)
	{
		//ip
		node_ok.begin = ip_deque[l1i->begin].begin;
		node_ok.end   = ip_deque[l1i->end].end;
		node.differ = differ(node_ok);
		//�ַ�
		node_ok.s1 = add_sub_str(all_map[l1i->max_id].s1);
		node_ok.s2 = add_sub_str(all_map[l1i->max_id].s2);
		node_ok.s  = l1i->max_id;
		//λ��
		node.a_off = node.c_off = node.l_off = -1;
		//���յ�
		node_ok.offset = now_offset;
		node_ok.data_len = 1 + node.differ;

		//����������
		make_data_piece(node_ok, node, true, false, null_ip_node);
		//���ӵ��ܵ�
		now_offset += node_ok.data_len;

		//�洢
		end_ip_deque1.push_back(node_ok);

#if defined debug_layer
		debug << ip2str(end_ip_deque1.back().begin) << "="
			<< ip2str(end_ip_deque1.back().end)     << " " 
			<< (unsigned int)((data_header*)temp_char)->differ << "=" 
			<< (unsigned int)((data_header*)temp_char)->jump << " "
			<< node.a_off << ":" << node.c_off << ":" << node.l_off 
			<< " offset:" << node.offset 
			<< " len:" << node.data_len
			<< endl
			<< all_map[end_ip_deque1.back().s].s1 << "+"
			<< all_map[end_ip_deque1.back().s].s2 << " "
			<< (unsigned int)all_map[end_ip_deque1.back().s].s1.length()+1 << "+"
			<< (unsigned int)all_map[end_ip_deque1.back().s].s2.length()+1
			<< endl << endl;
#endif
	}

#if defined debug_layer
	debug << "=========================================================" << endl;
#endif

	//����һ��
	deque<ip_node> end_ip_deque2;

	deque<ip_node>::iterator node_i = end_ip_deque1.begin();
	for(deque<ip_piece>::iterator l2i = ip_deque.begin(); l2i != ip_deque.end(); ++l2i)
	{
		if(node_i != end_ip_deque1.end() && l2i->end > node_i->end) //��һ��
			++node_i;
		if(node_i != end_ip_deque1.end() && l2i->s == node_i->s) //��ȫ����
			continue;

		bool use_father = false;

		//ip
		node_ok.begin = l2i->begin;
		node_ok.end   = l2i->end;
		node.differ = differ(node_ok);
		//�ַ�
		node_ok.s1 = l2i->s1;
		node_ok.s2 = l2i->s2;
		node_ok.s  = l2i->s;
		//λ��
		node.a_off = node.c_off = node.l_off = -1;
		//���յ�
		node_ok.offset = now_offset;
		node_ok.data_len = 1 + node.differ;

		//�Ƿ�ͬ��
		if( node_i != end_ip_deque1.end() )
		{
			if( (node_ok.s1 == node_i->s1 && !sub_map[node_ok.s1].str.empty()) ||
				(node_ok.s2 == node_i->s2 && !sub_map[node_ok.s2].str.empty()) )
				use_father = true;
		}

		//����������
		make_data_piece(node_ok, node, false, use_father, *node_i);
		//���ӵ��ܵ�
		now_offset += node_ok.data_len;

		//�洢
		end_ip_deque2.push_back(node_ok);

#if defined debug_layer
		debug << ip2str(end_ip_deque2.back().begin) << "="
			<< ip2str(end_ip_deque2.back().end)     << " " 
			<< (unsigned int)((data_header*)temp_char)->differ << "=" 
			<< (unsigned int)((data_header*)temp_char)->jump << " "
			<< node.a_off << ":" << node.c_off << ":" << node.l_off 
			<< " offset:" << node.offset 
			<< " len:" << node.data_len
			<< endl
			<< all_map[end_ip_deque2.back().s].s1 << "+"
			<< all_map[end_ip_deque2.back().s].s2 << " "
			<< (unsigned int)all_map[end_ip_deque2.back().s].s1.length()+1 << "+"
			<< (unsigned int)all_map[end_ip_deque2.back().s].s2.length()+1
			<< endl << endl;
#endif
	}
	//ddddd.print();

#if defined debug_layer
	debug.close();
#endif

	make_final(end_ip_deque1, end_ip_deque2, now_offset);
}

//����ipsearcher.dll�ļ�
inline void write_ipsearcher() 
{
	UINT idResource = 192;
	UINT idType = 200;

	char text[2048];
	//·��
	if( !GetModuleFileName(0, text, 2028) )
	{
		cout << "�޷�ȡ�õ�ǰ·��." << endl;
		return;
	}
	string path = string(text);

	DWORD cbRes;

	bool result = false ;
	do
	{
		//�õ�·��
		size_t l = path.rfind( "\\" );
		if( l == string::npos ) 
			break ;
		path = path.substr(0, l + 1);
		//����·��
		CreateDirectory( path.c_str(), NULL ) ;
		path.append("ipsearcher.dll");

		//������Դ
		HRSRC hResInfo = FindResource(NULL, MAKEINTRESOURCE(idResource), MAKEINTRESOURCE(idType));
		HGLOBAL hgRes = LoadResource(NULL, hResInfo);
		void *pvRes = LockResource(hgRes);
		cbRes = SizeofResource(NULL, hResInfo);

		//д��
		HANDLE hFile = CreateFileA(path.c_str() , GENERIC_WRITE, 0, 0, CREATE_ALWAYS,
			FILE_ATTRIBUTE_NORMAL, 0);
		DWORD cbWritten;
		if( hFile == INVALID_HANDLE_VALUE ) 
			break;
		WriteFile(hFile, pvRes, cbRes, &cbWritten, 0);
		CloseHandle(hFile);

		result = true ;
	}while(false);

	if( result )
		cout << "�ɹ�������ipsearcher.dll  ��" << cbRes/1024 << "KB" << endl;
	else
		cout << "����ipsearcher.dllʱ���ִ���,��ر����ڵ���ipsearcher.dll�ĳ���."
		<< endl;
}

//��qqwryװ��
bool read_qqwry()
{
	//װ�ص��ڴ�
	if( !load_qqwry() )
		return false;

	//���뵽ip_deque
	if( !read() )
		return false;

	return true;
}

void parse_arg(int argc, char* argv[])
{
	po::options_description od("ʹ��˵��");

	od.add_options()
		("input,i", po::value<string>()->default_value("qqwry.dat"), "�����ļ�")
		("output,o", po::value<string>()->default_value("ipwry.dat"), "����ļ�")
		("lzma,l", "ʹ��LZMAѹ������")
		("discard,d", po::value<string>()->default_value(""), "Ҫ�����ĵ�����ַ")
		("ipsearcher,f", "������˳���汾�����ipsearcher.dll")
		("gbwry,g", "����gbwry.dat�ļ�")
		("text,t", "�����ı��ļ�")
		("ver,v", "��ʾ�汾")
		("help,h", "����");

	//����
	po::parsed_options line = po::command_line_parser(argc, argv).options(od).run();
	po::variables_map vm;
	po::store(line, vm);
	po::notify(vm);    

	if(1 == argc)
		cout << "ʹ��\"ipwry -h\"����ɲ鿴����ѡ��" << endl;

	//����
	if( vm.count("help") ) 
	{
		g_env.do_ipwry = false;
		g_env.count_time = false;
		od.print(cout);
		return;
	}
	//�汾
	if( vm.count("ver") )
	{
		g_env.do_ipwry = false;
		g_env.count_time = false;
		cout << copyright << endl << "������ʹ�������³����:" << endl
			<< boost_ver << endl << lzma_ver << endl;
		return;
	}

	//�����ļ�
	if( vm.count("input") )
	{
		g_env.input_file = vm["input"].as<string>();
	}
	//����ļ�
	if( vm.count("output") )
	{
		g_env.output_file = vm["output"].as<string>();
	}
	//����dll
	if( vm.count("ipsearcher") )
	{
		g_env.ipsearcher = true;
		g_env.do_ipwry = false;
		g_env.count_time = false;
		return;
	}
	//����
	if( vm.count("discard") )
	{
		g_env.discard = vm["discard"].as<string>();
	}
	//����gbwry
	if( vm.count("gbwry") )
	{
		g_env.do_ipwry = false;
		g_env.do_gbwry = true;
		if( string("ipwry.dat") == g_env.output_file )
			g_env.output_file = "gbwry.dat";
		return;
	}
	//����text
	if( vm.count("text") )
	{
		g_env.do_ipwry = false;
		g_env.do_text = true;
		if( string("ipwry.dat") == g_env.output_file )
			g_env.output_file = "ipdata.txt";
		return;
	}

	//������ipwry��ѡ��-----------------------------------

	//ʹ��lzma
	if( vm.count("lzma") )
	{
		g_env.use_lzma = true;
	}
}

//������
int __cdecl main(int argc, char* argv[])
{
	cout << ver_str << endl;
	parse_arg(argc, argv);  //����������

	//��ʱ1
	unsigned int t1, t2;
	t1 = ::GetTickCount();

	if(g_env.do_ipwry)
	{
		if( !read_qqwry() )
			return -1;

		make_layer();
	}
	else if(g_env.do_gbwry)
	{
		if( !read_qqwry() )
			return -1;

		make_gbwry();
	}
	
	if(g_env.do_text)
	{
		if( !read_qqwry() )
			return -1;
	}

	if(g_env.ipsearcher)
	{
		g_env.count_time = false;
		write_ipsearcher();
	}

	//��ʱ2
	if( g_env.count_time )
	{
		t2 = ::GetTickCount();
		cout << "ת������" << (float)(t2 - t1)/1000 << "��" << endl;
	}

	return 0;
}

