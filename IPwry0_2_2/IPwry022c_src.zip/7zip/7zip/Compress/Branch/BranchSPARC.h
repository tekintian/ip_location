// BranchSPARC.h

#ifndef __BRANCH_SPARC_H
#define __BRANCH_SPARC_H

#include "Common/Types.h"

UInt32 SPARC_B_Convert(Byte *data, UInt32 size, UInt32 nowPos, int encoding);

#endif
